#include "StdAfx.h"
#include "LCCmdHandler.h"
#include "TranslateCmd.h"
#include "WaitQueue.h"
#include "ProtMapping.h"
#include "THSPDef.h"
#include "Global.h"
#include "ThLCDef.h"
//#include "ProtMapping.h"
//#include "..\BlendMgr\BlendMgr.h"
#include <algorithm>

//#pragma comment(lib, "BlendMgr")

WaitQueue g_WaitQueue;
//TaskInfoList g_TaskInfoList;
CRITICAL_SECTION g_CS;

typedef KSTATUS (*LCCmdHandler)(PROGRAM_OBJECT  PrgObject, PCOMM_CMD_DATA CmdData, DWORD DataLength, UCHAR OriginalCmd);

struct ResponseCmdPair
{
	UCHAR LCCmd;
	UCHAR UCOriginCmd;
	LCCmdHandler LCCmdFunc;
};

struct LCInnerHandleCmdPair
{
	UCHAR LCCmd;
	UCHAR UCResponseCmd;
	LCCmdHandler LCCmdFunc;
};

static KSTATUS ResponseUCCmd(UCHAR OriginalCmd)
{
	if( g_WaitQueue.SetWaitSuccess(OriginalCmd) )
		return STATUS_SUCCESS;
	
	return STATUS_UNKNOW_ERROR;
}

static KSTATUS ReturnEnableAutoCheckResult(PROGRAM_OBJECT  PrgObject, PCOMM_CMD_DATA CmdData, DWORD DataLength, UCHAR OriginalCmd)
{
	CHAR *OutBuffer = NULL;
	int OutBufferLength = 0;
	
	if( !g_WaitQueue.GetCmdBuffer(OriginalCmd, &OutBuffer, OutBufferLength) )
	{
		DbgPrint("retrieve buffer from queue failed!");
		return STATUS_UNKNOW_ERROR;
	}
	
	PENABLE_AUTO_CHECK_INFO EnableAutoCheckResult = (PENABLE_AUTO_CHECK_INFO)OutBuffer;
	if (CmdData->data[0] == 1)
	{
		EnableAutoCheckResult->IsSuccess = true;
	}
	else
	{
		EnableAutoCheckResult->IsSuccess = false;
	}
	
	return ResponseUCCmd(OriginalCmd);
}

static KSTATUS FinishClear(PROGRAM_OBJECT  PrgObject, PCOMM_CMD_DATA CmdData, DWORD DataLength, UCHAR OriginalCmd)
{
	CHAR *OutBuffer = NULL;
	int OutBufferLength = 0;
	
	if( !g_WaitQueue.GetCmdBuffer(OriginalCmd, &OutBuffer, OutBufferLength) )
	{
		DbgPrint("retrieve buffer from queue failed!");
		return STATUS_UNKNOW_ERROR;
	}
	
	PFINISH_CLEAR_INFO ClearResult = (PFINISH_CLEAR_INFO)OutBuffer;
	if (CmdData->data[0] == 1)
	{
		ClearResult->IsSuccess = true;
	}
	else
	{
		ClearResult->IsSuccess = false;
	}
	
	return ResponseUCCmd(OriginalCmd);
}

static KSTATUS LCStart(PROGRAM_OBJECT  PrgObject, PCOMM_CMD_DATA CmdData, DWORD DataLength, UCHAR OriginalCmd)
{
	LC_COMMAND UCCmdData = {0};

	ClearTask();
	
	UCCmdData.lc_header.flag = LC_FLAG;
	UCCmdData.lc_header.nLCCmd = LC_START_STATUS;

	return PostCmdToUC(PrgObject, &UCCmdData);
}

#define VALID_YEAR_INDEX 19
#define VALID_MONTH_INDEX 20
#define VALID_DATE_INDEX 21
#define ITMES_COUNT_BEFORE_VALID_DATE 19

static KSTATUS ReturnDataToUC(PROGRAM_OBJECT  PrgObject, PCOMM_CMD_DATA CmdData, DWORD DataLength, UCHAR OriginalCmd)
{
	CHAR *OutBuffer = NULL;
	int OutBufferLength = 0;
	
	if( !g_WaitQueue.GetCmdBuffer(OriginalCmd, &OutBuffer, OutBufferLength) )
	{
		DbgPrint("retrieve buffer from queue failed!");
		return STATUS_UNKNOW_ERROR;
	}
	
	ZeroMemory(OutBuffer, OutBufferLength);
	memcpy(OutBuffer, CmdData->data, DataLength);
	
	return ResponseUCCmd(OriginalCmd);
}

static KSTATUS NewTestTask(PROGRAM_OBJECT  PrgObject, PCOMM_CMD_DATA CmdData, DWORD DataLength, UCHAR OriginalCmd)
{
	LC_COMMAND Cmd = {0};
	PNEW_TASK NewTask = (PNEW_TASK) &Cmd;

	NewTask->lc_header.flag = LC_FLAG;
	NewTask->lc_header.nLCCmd = LC_NEW_TASK;

	PFINISH_ABSORBING_INFO AbsorbingInfo = (PFINISH_ABSORBING_INFO)CmdData->data;
	NewTask->ChannelNum = AbsorbingInfo->ChannelNum;
	NewTask->HoleNum = AbsorbingInfo->HoleNum;
	NewTask->IsSuccess = (OPER_SUCCESS == AbsorbingInfo->SuccessFlag? true:false);
	return PostCmdToUC(PrgObject, &Cmd);
}

static KSTATUS FinishSelfCheck(PROGRAM_OBJECT  PrgObject, PCOMM_CMD_DATA CmdData, DWORD DataLength, UCHAR OriginalCmd)
{
	LC_COMMAND Cmd = {0};
	PLC_REPORT_INFORMATION ReportInfo = (PLC_REPORT_INFORMATION) &Cmd;
	PLC_FINISH_SELF_CHECK FinishSelfCheckInfo = (PLC_FINISH_SELF_CHECK) ReportInfo->Reserved;
	
	ReportInfo->lc_header.flag = LC_FLAG;
	ReportInfo->lc_header.nLCCmd = LC_REPORT_ACTION;
	ReportInfo->nInfomationType = OriginalCmd;

	if( CmdData->data[0] == 1)
		FinishSelfCheckInfo->IsSuccess = true;
	else
		FinishSelfCheckInfo->IsSuccess = false;
	
	return PostCmdToUC(PrgObject, &Cmd);
}

static KSTATUS NotifySampling(PROGRAM_OBJECT  PrgObject, PCOMM_CMD_DATA CmdData, DWORD DataLength, UCHAR OriginalCmd)
{
	LC_COMMAND Cmd = {0};
	PLC_START_SAMPLE_INFO StartSampleInfo = (PLC_START_SAMPLE_INFO) &Cmd;
	
	StartSampleInfo->lc_header.flag = LC_FLAG;
	StartSampleInfo->lc_header.nLCCmd = LC_START_SAMPLING;
	
	PFINISH_STANDING_INFO SampleInfo = (PFINISH_STANDING_INFO)CmdData->data;
	StartSampleInfo->StartSampleInfo.ChannelNum = SampleInfo->ChannelNum;
	StartSampleInfo->StartSampleInfo.HoleNum = SampleInfo->HoleNum;
	StartSampleInfo->StartSampleInfo.TaskID = SampleInfo->TaskID;
	return PostCmdToUC(PrgObject, &Cmd);
}

static KSTATUS FinishMoveMicroscope(PROGRAM_OBJECT  PrgObject, PCOMM_CMD_DATA CmdData, DWORD DataLength, UCHAR OriginalCmd)
{
	//both PROTO_UC_LOCATE_10_MICROSCOPE and PROTO_UC_LOCATE_10_MICROSCOPE are responded by PROTO_LC_FINISH_LOCATE_MICROSCOPE;
	if( g_WaitQueue.IsItemExist(PROTO_UC_LOCATE_10_MICROSCOPE) )
		return ResponseUCCmd(PROTO_UC_LOCATE_10_MICROSCOPE);
	else
		return ResponseUCCmd(PROTO_UC_LOCATE_40_MICROSCOPE);
}

static KSTATUS UDCCheck(PROGRAM_OBJECT  PrgObject, PCOMM_CMD_DATA CmdData, DWORD DataLength, UCHAR OriginalCmd)
{
	LC_COMMAND Cmd = {0};
	PLC_START_UDC_CHECK_INFO StartCheckUDCInfo = (PLC_START_UDC_CHECK_INFO) &Cmd;

	StartCheckUDCInfo->lc_header.flag = LC_FLAG;
	StartCheckUDCInfo->lc_header.nLCCmd = LC_START_UDC_CHECK;
	
	PUDC_CHECK_INFO UDCCheckInfo = (PUDC_CHECK_INFO)CmdData->data;
	StartCheckUDCInfo->UDCCheckInfo.HoleNum = UDCCheckInfo->HoleNum;
	StartCheckUDCInfo->UDCCheckInfo.TaskID = UDCCheckInfo->TaskID;
	return PostCmdToUC(PrgObject, &Cmd);
}

#pragma pack(1)

struct CBarcodeInfo
{
	UCHAR HoleNum;
	WORD TaskID;
	UCHAR Barcode[MAX_PATH];                      
};
typedef CBarcodeInfo *PCBarcodeInfo;

#pragma pack()

#define BARCODE_END_CHARACTER 0x0d

static KSTATUS ReportBarcode(PROGRAM_OBJECT  PrgObject, PCOMM_CMD_DATA CmdData, DWORD DataLength, UCHAR OriginalCmd)
{
	LC_COMMAND Cmd = {0};
	PLC_BARCODE_INFO BarcodeInfo = (PLC_BARCODE_INFO) &Cmd;
	
	BarcodeInfo->lc_header.flag = LC_FLAG;
	BarcodeInfo->lc_header.nLCCmd = LC_BARCODE;
	
	PCBarcodeInfo LCBarcodeInfo = (PCBarcodeInfo)CmdData->data;

	BarcodeInfo->BarcodeInfo.HoleNum = LCBarcodeInfo->HoleNum;
	BarcodeInfo->BarcodeInfo.TaskID = LCBarcodeInfo->TaskID;

	for (int i = 0; i < DataLength - sizeof(LCBarcodeInfo->HoleNum) - sizeof(LCBarcodeInfo->TaskID); ++i )
	{
		if (LCBarcodeInfo->Barcode[i] == BARCODE_END_CHARACTER)
			break;

		BarcodeInfo->BarcodeInfo.Barcode[i] = LCBarcodeInfo->Barcode[i];
	}

	return PostCmdToUC(PrgObject, &Cmd);
}


static KSTATUS ReportTaskStatus(PROGRAM_OBJECT  PrgObject, PCOMM_CMD_DATA CmdData, DWORD DataLength, UCHAR OriginalCmd)
{
	LC_COMMAND Cmd = {0};
	PLC_REPORT_INFORMATION ReportInfo = (PLC_REPORT_INFORMATION) &Cmd;
	
	ReportInfo->lc_header.flag = LC_FLAG;
	ReportInfo->lc_header.nLCCmd = LC_REPORT_ACTION;
	ReportInfo->nInfomationType = OriginalCmd;

	return PostCmdToUC(PrgObject, &Cmd);
}

static KSTATUS ReportLCFailureInfo(PROGRAM_OBJECT  PrgObject, PCOMM_CMD_DATA CmdData, DWORD DataLength, UCHAR OriginalCmd)
{
	LC_COMMAND Cmd = {0};
	PLC_REPORT_INFORMATION ReportInfo = (PLC_REPORT_INFORMATION) &Cmd;
	
	ReportInfo->lc_header.flag = LC_FLAG;
	ReportInfo->lc_header.nLCCmd = LC_REPORT_ACTION;
	ReportInfo->nInfomationType = OriginalCmd;

	PLC_FAILURE_INFO LCFailureInfo = (PLC_FAILURE_INFO) CmdData->data;
	memcpy( ReportInfo->Reserved, LCFailureInfo, sizeof(LC_FAILURE_INFO) );
	
	return PostCmdToUC(PrgObject, &Cmd);
}

#define WARNING_INFO_COUNT 6

struct LC_WARNING_INFO
{
	UCHAR WarningInfo[WARNING_INFO_COUNT];
};
typedef LC_WARNING_INFO *PLC_WARNING_INFO;

static UCHAR WarningInfoList[] = { REPORT_DAILY_CLEANER_EMPTY, REPORT_PAPER_STUCK, REPORT_PIPE_FULL, REPORT_NO_PAPER, REPORT_STRENGTHEN_CLEANER_EMPTY, REPORT_KEEP_CLEANER_EMPTY };

static KSTATUS ReportLCWarningInfo(PROGRAM_OBJECT  PrgObject, PCOMM_CMD_DATA CmdData, DWORD DataLength, UCHAR OriginalCmd)
{
	LC_COMMAND Cmd = {0};
	PLC_REPORT_INFORMATION ReportInfo = (PLC_REPORT_INFORMATION) &Cmd;
	
	ReportInfo->lc_header.flag = LC_FLAG;
	ReportInfo->lc_header.nLCCmd = LC_REPORT_ACTION;
	//ReportInfo->nInfomationType = OriginalCmd;
	
	PLC_WARNING_INFO LCWarningInfo = (PLC_WARNING_INFO) CmdData->data;
	for( int Index = 0; Index < WARNING_INFO_COUNT; ++Index)
	{
		if (LCWarningInfo->WarningInfo[Index] != 0)
		{
			ReportInfo->nInfomationType = WarningInfoList[Index];
			break;
		}
	}
	//memcpy( ReportInfo->Reserved, LCWarningInfo, sizeof(LC_WARNING_INFO) );
	
	return PostCmdToUC(PrgObject, &Cmd);
}

static KSTATUS ReturnZPos(PROGRAM_OBJECT  PrgObject, PCOMM_CMD_DATA CmdData, DWORD DataLength, UCHAR OriginalCmd)
{
	LC_COMMAND Cmd = {0};
	PLC_QUERY_Z_POS_INFO ZPosInfo = (PLC_QUERY_Z_POS_INFO) &Cmd;
	
	ZPosInfo->lc_header.flag = LC_FLAG;
	ZPosInfo->lc_header.nLCCmd = LC_QUERY_Z_POS;

	PQUERY_Z_POS_INFO LCZPosInfo = (PQUERY_Z_POS_INFO)CmdData->data;
	ZPosInfo->PosInfo.PosNum = LCZPosInfo->PosNum;
	ZPosInfo->PosInfo.StepCountHigh = LCZPosInfo->StepCountHigh;
	ZPosInfo->PosInfo.StepCountLow = LCZPosInfo->StepCountLow;
	
	return PostCmdToUC(PrgObject, &Cmd);
}

static KSTATUS ReturnMicroDeviation(PROGRAM_OBJECT  PrgObject, PCOMM_CMD_DATA CmdData, DWORD DataLength, UCHAR OriginalCmd)
{
	LC_COMMAND Cmd = {0};
	PLC_XY_40_MICRO_DEVIA_INFO DeviationInfo = (PLC_XY_40_MICRO_DEVIA_INFO) &Cmd;
	
	DeviationInfo->lc_header.flag = LC_FLAG;
	DeviationInfo->lc_header.nLCCmd = LC_RETURN_XY_40_MICRO_DEVIA;
	
	PXY_40_MICRO_DEVIA_INFO LCDeviationInfo = (PXY_40_MICRO_DEVIA_INFO)CmdData->data;
	DeviationInfo->DeviaInfo.XDeviationHigh = LCDeviationInfo->XDeviationHigh;
	DeviationInfo->DeviaInfo.XDeviationLow = LCDeviationInfo->XDeviationLow;
	DeviationInfo->DeviaInfo.YDeviationHigh = LCDeviationInfo->YDeviationHigh;
	DeviationInfo->DeviaInfo.YDeviationLow = LCDeviationInfo->YDeviationLow;
	
	return PostCmdToUC(PrgObject, &Cmd);
}

static KSTATUS ReturnClearStatus(PROGRAM_OBJECT  PrgObject, PCOMM_CMD_DATA CmdData, DWORD DataLength, UCHAR OriginalCmd)
{
	CHAR *OutBuffer = NULL;
	int OutBufferLength = 0;
	PCLEAR_TROUBLE_INFO OperationResult = (PCLEAR_TROUBLE_INFO)CmdData->data;
	
	if( !g_WaitQueue.GetCmdBuffer(OriginalCmd, &OutBuffer, OutBufferLength) )
	{
		DbgPrint("retrieve buffer from queue failed!");
		return STATUS_UNKNOW_ERROR;
	}
	
	ZeroMemory(OutBuffer, OutBufferLength);
	memcpy( OutBuffer, OperationResult, sizeof(CLEAR_TROUBLE_INFO) );
	return ResponseUCCmd(OriginalCmd);
} 

static KSTATUS ResponseCorrectModule(PROGRAM_OBJECT  PrgObject, PCOMM_CMD_DATA CmdData, DWORD DataLength, UCHAR OriginalCmd)
{
	CHAR *OutBuffer = NULL;
	int OutBufferLength = 0;

	if( !g_WaitQueue.GetCmdBuffer(OriginalCmd, &OutBuffer, OutBufferLength) )
	{
		DbgPrint("retrieve buffer from queue failed!");
		return STATUS_UNKNOW_ERROR;
	}

	PCORRECT_MODULE_INFO CorrectModuleInfo = (PCORRECT_MODULE_INFO)OutBuffer;
	if (CmdData->data[0] == 0x00)
	{
		DbgPrint("ResponseCorrectModule 00000000000");
		CorrectModuleInfo->IsSuccess = true;
	}
	else
	{
		DbgPrint("ResponseCorrectModule 11111111111");
		CorrectModuleInfo->IsSuccess = false;
	}

	return ResponseUCCmd(OriginalCmd);
}

static KSTATUS ReturnSpecifyPaperTypeResult(PROGRAM_OBJECT  PrgObject, PCOMM_CMD_DATA CmdData, DWORD DataLength, UCHAR OriginalCmd)
{
	CHAR *OutBuffer = NULL;
	int OutBufferLength = 0;

	if( !g_WaitQueue.GetCmdBuffer(OriginalCmd, &OutBuffer, OutBufferLength) )
	{
		DbgPrint("retrieve buffer from queue failed!");
		return STATUS_UNKNOW_ERROR;
	}

	bool *Result = (bool *)OutBuffer;
	if (CmdData->data[0] == 0x00)
	{
		*Result = true;
	}
	else
	{
		*Result = false;
	}

	return ResponseUCCmd(OriginalCmd);
}

static KSTATUS IsAllowTest(PROGRAM_OBJECT  PrgObject, PCOMM_CMD_DATA CmdData, DWORD DataLength, UCHAR OriginalCmd)
{
	LC_COMMAND Cmd = {0};

	Cmd.lc_header.flag   = LC_FLAG;
	Cmd.lc_header.nLCCmd = LC_ALLOW_TEST;

	return PostCmdToUC(PrgObject, &Cmd);
}

static KSTATUS QueryConsumables(PROGRAM_OBJECT  PrgObject, PCOMM_CMD_DATA CmdData, DWORD DataLength, UCHAR OriginalCmd)
{
	LC_COMMAND Cmd = { 0 };

	Cmd.lc_header.flag = LC_FLAG;
	Cmd.lc_header.nLCCmd = LC_CONSUMABLE_SURPLUS;

	return PostCmdToUC(PrgObject, &Cmd);
}

static KSTATUS JustResponseUCCmd(PROGRAM_OBJECT  PrgObject, PCOMM_CMD_DATA CmdData, DWORD DataLength, UCHAR OriginalCmd)
{
	return ResponseUCCmd(OriginalCmd);
}

static KSTATUS JustPostCmdToUS(PROGRAM_OBJECT  PrgObject, PCOMM_CMD_DATA CmdData, DWORD DataLength, UCHAR UCIndependentCmd)
{
	LC_COMMAND Cmd = {0};

	Cmd.lc_header.flag   = LC_FLAG;
	Cmd.lc_header.nLCCmd = UCIndependentCmd;

	return PostCmdToUC(PrgObject, &Cmd);
}

static KSTATUS UDCResult(PROGRAM_OBJECT  PrgObject, PCOMM_CMD_DATA CmdData, DWORD DataLength, UCHAR OriginalCmd)
{
	LC_COMMAND Cmd = {0};
	PLC_TEST_PAPER_INFO TestResultInfo=(PLC_TEST_PAPER_INFO)&Cmd;
	TestResultInfo->lc_header.flag = LC_FLAG;
	TestResultInfo->lc_header.nLCCmd = LC_START_UDC_CHECK;

	PTEST_PAPER_INFO LCTestResult=(PTEST_PAPER_INFO)CmdData->data;

	memcpy(&(TestResultInfo->TestResult),LCTestResult, sizeof(TEST_PAPER_INFO));

	return PostCmdToUC(PrgObject, &Cmd);
}

static ResponseCmdPair g_ResponseCmdList[] = 
{
	PROTO_LC_START_SELF_CHECK,					PROTO_UC_SELF_CHECK,				JustResponseUCCmd,
	PROTO_LC_RESPOND_ENABLE_AUTO_CHECK,			PROTO_UC_ENABLE_AUTO_CHECK,			ReturnEnableAutoCheckResult,
	PROTO_LC_RESPOND_DISABLE_AUTO_CHECK,		PROTO_UC_DISABLE_AUTO_CHECK,		JustResponseUCCmd,
	PROTO_LC_FINISH_ABSORBING,					INVALID_CMD,						NewTestTask,
	PROTO_LC_FINISH_STANDING,					INVALID_CMD,						NotifySampling,
	PROTO_LC_FINISH_LOCATE_MICROSCOPE,			INVALID_CMD,						FinishMoveMicroscope,
	PROTO_LC_UDC_CHECK,							INVALID_CMD,						UDCCheck,
	PROTO_LC_BARCODE_INFO,						INVALID_CMD,						ReportBarcode,
	PROTO_LC_A_NEW_PIPE,						REPORT_PIPE_IN_INFO,				ReportTaskStatus,
	PROTO_LC_FINISH_A_PIPE,						REPORT_PIPE_OUT_INFO,				ReportTaskStatus,
	PROTO_LC_RETURN_Z_POS,						PROTO_UC_QUERY_Z_POS,				ReturnDataToUC,
	PROTO_LC_RETURN_XY_40_MICRO_DEVIA,			PROTO_UC_QUERY_XY_40_MICRO_DEVIA,   ReturnDataToUC,
	PROTO_LC_FINISH_CLEAR,						PROTO_UC_CLEAR,						FinishClear,
	PROTO_LC_FINISH_FORCE_CLEAR,				PROTO_UC_FORCE_CLEAR,				FinishClear,
	PROTO_LC_RETURN_LC_PARAMETERS,				PROTO_UC_GET_LC_PARAMETERS,			ReturnDataToUC,
	PROTO_LC_FINISH_SET_LC_PARAMETERS,			PROTO_UC_SET_LC_PARAMETERS,			JustResponseUCCmd,
	PROTO_LC_RETURN_ENTER_HARDWARE_DEBUG,		PROTO_UC_ENTER_HARDWARE_DEBUG,		JustResponseUCCmd,
	PROTO_LC_RETURN_EXIT_HARDWARE_DEBUG,		PROTO_UC_EXIT_HARDWARE_DEBUG,		JustResponseUCCmd,
	PROTO_LC_RESTART_SUCCESS,					INVALID_CMD,						LCStart,
	PROTO_LC_FAILURE_INFO,						REPORT_LC_FAILURE,					ReportLCFailureInfo,
	PROTO_LC_WARNING_INFO,						INVALID_CMD,					    ReportLCWarningInfo,
	PROTO_LC_FINISH_MOVE_SCAN_PLATFORM,			PROTO_UC_MOVE_SCAN_PLATFORM,		JustResponseUCCmd,
	PROTO_LC_FINISH_RESET_Z,					PROTO_UC_RESET_Z,					JustResponseUCCmd,
	PROTO_LC_FINISH_RESET_X,					PROTO_UC_RESET_X,					JustResponseUCCmd,
	PROTO_LC_FINISH_RESET_Y,					PROTO_UC_RESET_Y,					JustResponseUCCmd,
	PROTO_LC_FINISH_MOVE_Z,						PROTO_UC_MOVE_Z,					JustResponseUCCmd,
	PROTO_LC_FINISH_SELF_CHECK,					REPORT_FINISH_SELF_CHECK,			FinishSelfCheck,
	PROTO_LC_FINISH_SWITCH_CHANNEL,				PROTO_UC_SWITCH_CHANNEL,			JustResponseUCCmd,
	PROTO_LC_FINISH_SWITCH_MICROSCOPE,			PROTO_UC_SWITCH_MICROSCOPE,			JustResponseUCCmd,

	/*
	//�ɻ������
	PROTO_LC_RESPOND_TEST_PAPER,				INVALID_CMD,						UDCResult,
	// ���Է���
	PROTO_LC_RESPOND_TEST_PAPER2,				PROTO_UC_TEST_PAPER,				ReturnDataToUC,
	//����У׼
	PROTO_LC_RESPOND_CORRECT_MODULE,			PROTO_UC_CORRECT_MODULE,			ResponseCorrectModule,
	//����У׼
	PROTO_LC_RESPOND_CORRECT_MODULE_EX,         PROTO_UC_CORRECT_MODULE_EX,         ResponseCorrectModule,
	//�������ͷ���
	PROTO_LC_RESPOND_SPECIFY_PAPER_TYPE,		INVALID_CMD,		                ReturnSpecifyPaperTypeResult,
	//z���ƶ�����//20160626
	PROTO_LC_RESPOND_FOCUMOVE_Z,                PROTO_UC_FOCUSMOVE_Z,               JustResponseUCCmd,
	//taskID��λ���յ�����
	PROTO_LC_RESPOND_TASK_ID,                   PROTO_UC_NOTIFY_TASK_ID,            JustResponseUCCmd,
	//����ADֵ
	PROTO_LC_SENDAD,                            PROTO_UC_GETAD,                     ReturnDataToUC,
	//�Ƿ����
	PROTO_LC_RESPOND_ALLOWTEST,                 INVALID_CMD,					    IsAllowTest,
	*/

	//��ѯ�Ĳı�־λ
	PROTO_LC_QUERY_CONSUMABLES,					INVALID_CMD,						QueryConsumables,
};

template<class T>
bool IsLCCmdInQueue(T *Queue, DWORD ItemCount, DWORD Cmd, DWORD &CmdIndex)
{
	for ( CmdIndex = 0; CmdIndex < ItemCount; ++CmdIndex)
	{
		if (Queue[CmdIndex].LCCmd == Cmd)
		{
			return true;
		}
	}
	
	return false;
}

static bool IsResponseCmd(DWORD Cmd, DWORD &CmdIndex)
{
	return IsLCCmdInQueue(g_ResponseCmdList, GetItemCount(g_ResponseCmdList), Cmd, CmdIndex);
}

KSTATUS HandleLCCmd(PROGRAM_OBJECT  PrgObject, PRP prp)
{
	KSTATUS              Status = STATUS_SUCCESS;
	PCOMM_CMD_DATA		 CmdData = NULL;
	PRCV_BUFFER_PROC     rcv_buff;
	ULONG                nInSize;
	DWORD				 CmdIndex = 0;
	DWORD				 DataLengthInCmd = 0;
	
	DbgPrint("enter HandleLCCmd\n");
	
	Status = FMMC_GetPRPParmeters(prp, (PVOID*)&rcv_buff, &nInSize, NULL, NULL);
	CheckResultCode("HandleLCCmd", "FMMC_GetPRPParmeters", Status);
	
	if( rcv_buff->bParsePro == FALSE || rcv_buff->nRcvSize < COMM_CMD_LENGTH )
	{
		DbgPrint( "rcv_buff->bParsePro == FALSE || rcv_buff->nRcvSize < DBFJ_CMD_LENGTH" );
		Status = STATUS_INVALID_PARAMETERS;
		goto end;
	}
	
	
	DataLengthInCmd = rcv_buff->nRcvSize - 1;
	CmdData = (PCOMM_CMD_DATA)rcv_buff->pRcvBuffer;
	DbgPrint("receive lc cmd: %#x", CmdData->nCmd);
	
	if ( IsResponseCmd(CmdData->nCmd, CmdIndex) )
	{
		Status = g_ResponseCmdList[CmdIndex].LCCmdFunc(PrgObject, CmdData, DataLengthInCmd, g_ResponseCmdList[CmdIndex].UCOriginCmd);
	}
	else
	{
		DbgPrint("unhandled cmd:0x%x!!!!!", CmdData->nCmd);
		Status = STATUS_UNKNOW_ERROR;
	}

end:
	DbgPrint("leave HandleLCCmd\n");
	return Status;
}
