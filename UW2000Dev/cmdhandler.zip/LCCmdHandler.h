#ifndef HANDLE_LC_CMD_H
#define HANDLE_LC_CMD_H

#include "f_err.h"
#include "fmmc.h"

KSTATUS HandleLCCmd(PROGRAM_OBJECT  PrgObject, PRP prp);


#endif	//HANDLE_LC_CMD_H