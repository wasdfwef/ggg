#include "StdAfx.h"
#include "UCCmdHandler.h"
#include "TranslateCmd.h"
#include "WaitQueue.h"
#include "ProtMapping.h"
#include "ThLCDef.h"
#include "interal.h"
#include "Global.h"
#include "lc_interface.h"
#include "THSPDef.h"

#define TIME_INTERVAL_2S				2*1000
#define TIME_INTERVAL_5S				5*1000
#define TIME_INTERVAL_10S				10*1000
#define TIME_INTERVAL_25S				25*1000
#define TIME_INTERVAL_30S				30*1000
#define TIME_INTERVAL_60S				60*1000
#define TIME_INTERVAL_240S				240*1000
#define TIME_INTERVAL_510S				510*1000
#define INVALID_TIME_INTERVAL			0XFFFFFFFF


typedef KSTATUS (*UCCmdHandler)(PROGRAM_OBJECT ProgramObject,  PLC_COMMAND Command, UCHAR ProtocolCmd, DWORD TimeoutInterval);


struct UCProtocolCmdInfo
{
	UCHAR UCCmd;
	UCHAR UCProtocolCmd;
	UCCmdHandler UCCmdFunc; 
	DWORD TimeoutInterval;
};


void ClearTask()
{
	g_WaitQueue.Clear();
}


static KSTATUS JustSendCmdToLC(PROGRAM_OBJECT PrgObject, PLC_COMMAND Command, UCHAR ProtocolCmd, DWORD TimeoutInterval)
{
	COMM_CMD_DATA CmdData = {0};
	
	CmdData.nCmd = ProtocolCmd;
	return SendCmdToLC(PrgObject, &CmdData, COMM_CMD_LENGTH, NULL, 0, TimeoutInterval);
}


static KSTATUS EnableAutoCheck(PROGRAM_OBJECT PrgObject, PLC_COMMAND Command, UCHAR ProtocolCmd, DWORD TimeoutInterval)
{
	COMM_CMD_DATA CmdData = {0};
	PENABLE_AUTO_CHECK_INFO EnableResult = (PENABLE_AUTO_CHECK_INFO)Command->Reserved;
	
	CmdData.nCmd = ProtocolCmd;
	return SendCmdToLC( PrgObject, &CmdData, COMM_CMD_LENGTH, (char *)EnableResult, sizeof(ENABLE_AUTO_CHECK_INFO), TimeoutInterval );
}


static KSTATUS ClearLC(PROGRAM_OBJECT PrgObject, PLC_COMMAND Command, UCHAR ProtocolCmd, DWORD TimeoutInterval)
{
	COMM_CMD_DATA CmdData = {0};
	PFINISH_CLEAR_INFO ClearResult = (PFINISH_CLEAR_INFO)Command->Reserved;
	
	CmdData.nCmd = ProtocolCmd;
	return SendCmdToLC( PrgObject, &CmdData, COMM_CMD_LENGTH, (char *)ClearResult, sizeof(FINISH_CLEAR_INFO), TimeoutInterval );
}


static KSTATUS GetLCParameters(PROGRAM_OBJECT PrgObject, PLC_COMMAND Command, UCHAR ProtocolCmd, DWORD TimeoutInterval)
{
	COMM_CMD_DATA CmdData = {0};
	PLC_PARAMETERS_INFO LCParametersInfo = (PLC_PARAMETERS_INFO)Command->Reserved;
	
	CmdData.nCmd = ProtocolCmd;
	return SendCmdToLC( PrgObject, &CmdData, COMM_CMD_LENGTH, (char *)LCParametersInfo, sizeof(LC_PARAMETERS_INFO), TimeoutInterval );
}


static KSTATUS QueryZPos(PROGRAM_OBJECT PrgObject, PLC_COMMAND Command, UCHAR ProtocolCmd, DWORD TimeoutInterval)
{
	COMM_CMD_DATA CmdData = {0};
	PQUERY_Z_POS_INFO LCZPosInfo = (PQUERY_Z_POS_INFO)Command->Reserved;
	
	CmdData.nCmd = ProtocolCmd;
	return SendCmdToLC( PrgObject, &CmdData, COMM_CMD_LENGTH, (char *)LCZPosInfo, sizeof(QUERY_Z_POS_INFO), TimeoutInterval );
}


static KSTATUS QueryXy40MicroDevia(PROGRAM_OBJECT PrgObject, PLC_COMMAND Command, UCHAR ProtocolCmd, DWORD TimeoutInterval)
{
	COMM_CMD_DATA CmdData = {0};
	PXY_40_MICRO_DEVIA_INFO MicroDeviaInfo = (PXY_40_MICRO_DEVIA_INFO)Command->Reserved;
	
	CmdData.nCmd = ProtocolCmd;
	return SendCmdToLC( PrgObject, &CmdData, COMM_CMD_LENGTH, (char *)MicroDeviaInfo, sizeof(XY_40_MICRO_DEVIA_INFO), TimeoutInterval );
}


static KSTATUS SetLCParameters(PROGRAM_OBJECT PrgObject, PLC_COMMAND Command, UCHAR ProtocolCmd, DWORD TimeoutInterval)
{
	char CmdBuffer[100] = {0};
	PCOMM_CMD_DATA CmdData = (PCOMM_CMD_DATA)CmdBuffer;
	PLC_PARAMETERS_INFO LCParametersInfo = (PLC_PARAMETERS_INFO)Command->Reserved;
	
	CmdData->nCmd = ProtocolCmd;
	memcpy( CmdData->data, LCParametersInfo, sizeof(LC_PARAMETERS_INFO) );
	return SendCmdToLC( PrgObject, CmdData, COMM_CMD_LENGTH + sizeof(LC_PARAMETERS_INFO), NULL, 0, TimeoutInterval );
}


static KSTATUS NotifyTaskID(PROGRAM_OBJECT ProgramObject,  PLC_COMMAND Command, UCHAR ProtocolCmd, DWORD TimeoutInterval)
{
	UCHAR CmdDataBuffer[20] = {0};
	PCOMM_CMD_DATA CmdData = (PCOMM_CMD_DATA)CmdDataBuffer;
	PTASKID_INFO TaksIDInfo = (PTASKID_INFO)Command->Reserved;
	
	CmdData->nCmd = ProtocolCmd;
	memcpy( CmdData->data, TaksIDInfo, sizeof(TASKID_INFO) );
	
	return PostCmdToLC( ProgramObject, CmdData, sizeof(CmdData->nCmd) + sizeof(TASKID_INFO) );
}


static KSTATUS Locate10Microscope(PROGRAM_OBJECT ProgramObject,  PLC_COMMAND Command, UCHAR ProtocolCmd, DWORD TimeoutInterval)
{
	UCHAR CmdDataBuffer[20] = {0};
	PCOMM_CMD_DATA CmdData = (PCOMM_CMD_DATA)CmdDataBuffer;
	PLOCATE_10_MICROSCOPE_INFO Move10MicroscopeInfo = (PLOCATE_10_MICROSCOPE_INFO)Command->Reserved;
	
	CmdData->nCmd = ProtocolCmd;
	memcpy( CmdData->data, Move10MicroscopeInfo, sizeof(LOCATE_10_MICROSCOPE_INFO) );

	if (RETURN_SAMPLE_CMD == Move10MicroscopeInfo->IsReturnTakePicCommand)
	{
		return SendCmdToLC( ProgramObject, CmdData, sizeof(CmdData->nCmd) + sizeof(LOCATE_10_MICROSCOPE_INFO), NULL, 0, TimeoutInterval );
	}
	else
	{
		return PostCmdToLC( ProgramObject, CmdData, sizeof(CmdData->nCmd) + sizeof(LOCATE_10_MICROSCOPE_INFO) );
	}
}


static KSTATUS Locate40Microscope(PROGRAM_OBJECT ProgramObject,  PLC_COMMAND Command, UCHAR ProtocolCmd, DWORD TimeoutInterval)
{
	UCHAR CmdDataBuffer[20] = {0};
	PCOMM_CMD_DATA CmdData = (PCOMM_CMD_DATA)CmdDataBuffer;
	PLOCATE_40_MICROSCOPE_INFO Move40MicroscopeInfo = (PLOCATE_40_MICROSCOPE_INFO)Command->Reserved;
	
	CmdData->nCmd = ProtocolCmd;
	memcpy( CmdData->data, Move40MicroscopeInfo, sizeof(LOCATE_40_MICROSCOPE_INFO) );
	
	if (RETURN_SAMPLE_CMD == Move40MicroscopeInfo->IsReturnTakePicCommand)
	{
		return SendCmdToLC( ProgramObject, CmdData, sizeof(CmdData->nCmd) + sizeof(LOCATE_40_MICROSCOPE_INFO), NULL, 0, TimeoutInterval );
	}
	else
	{
		return PostCmdToLC( ProgramObject, CmdData, sizeof(CmdData->nCmd) + sizeof(LOCATE_40_MICROSCOPE_INFO) );
	}
}


static KSTATUS FinishSample(PROGRAM_OBJECT ProgramObject,  PLC_COMMAND Command, UCHAR ProtocolCmd, DWORD TimeoutInterval)
{
	UCHAR CmdDataBuffer[20] = {0};
	PCOMM_CMD_DATA CmdData = (PCOMM_CMD_DATA)CmdDataBuffer;
	PFINISH_TAKE_PIC_INFO FinishSampleInfo = (PFINISH_TAKE_PIC_INFO)Command->Reserved;
	
	CmdData->nCmd = ProtocolCmd;
	memcpy( CmdData->data, FinishSampleInfo, sizeof(FINISH_TAKE_PIC_INFO) );
	
	return PostCmdToLC( ProgramObject, CmdData, sizeof(CmdData->nCmd) + sizeof(FINISH_TAKE_PIC_INFO) );
}


static KSTATUS StartSpecialTest(PROGRAM_OBJECT ProgramObject,  PLC_COMMAND Command, UCHAR ProtocolCmd, DWORD TimeoutInterval)
{
	UCHAR CmdDataBuffer[20] = {0};
	PCOMM_CMD_DATA CmdData = (PCOMM_CMD_DATA)CmdDataBuffer;
	PSPECIAL_TEST_INFO SpecialTestInfo = (PSPECIAL_TEST_INFO)Command->Reserved;
	
	CmdData->nCmd = ProtocolCmd;
	memcpy( CmdData->data, SpecialTestInfo, sizeof(SPECIAL_TEST_INFO) );
	
	return PostCmdToLC( ProgramObject, CmdData, sizeof(CmdData->nCmd) + sizeof(SPECIAL_TEST_INFO) );
}


static KSTATUS MoveScanPlatform(PROGRAM_OBJECT ProgramObject,  PLC_COMMAND Command, UCHAR ProtocolCmd, DWORD TimeoutInterval)
{
	UCHAR CmdDataBuffer[20] = {0};
	PCOMM_CMD_DATA CmdData = (PCOMM_CMD_DATA)CmdDataBuffer;
	PMOVE_SCAN_PLATFORM_INFO ScanPlatformInfo = (PMOVE_SCAN_PLATFORM_INFO)Command->Reserved;
	
	CmdData->nCmd = ProtocolCmd;
	memcpy( CmdData->data, ScanPlatformInfo, sizeof(MOVE_SCAN_PLATFORM_INFO) );
	
	return SendCmdToLC( ProgramObject, CmdData, sizeof(CmdData->nCmd) + sizeof(MOVE_SCAN_PLATFORM_INFO), NULL, 0, TimeoutInterval );
}


static KSTATUS MoveZAxis(PROGRAM_OBJECT ProgramObject,  PLC_COMMAND Command, UCHAR ProtocolCmd, DWORD TimeoutInterval)
{
	UCHAR CmdDataBuffer[20] = {0};
	PCOMM_CMD_DATA CmdData = (PCOMM_CMD_DATA)CmdDataBuffer;
	PMOVE_Z_AXIS MoveInfo = (PMOVE_Z_AXIS)Command->Reserved;
	
	CmdData->nCmd = ProtocolCmd;
	memcpy( CmdData->data, MoveInfo, sizeof(MOVE_Z_AXIS) );
	
	return SendCmdToLC( ProgramObject, CmdData, sizeof(CmdData->nCmd) + sizeof(MOVE_SCAN_PLATFORM_INFO), NULL, 0, TimeoutInterval );
}



static KSTATUS ControlLight(PROGRAM_OBJECT ProgramObject,  PLC_COMMAND Command, UCHAR ProtocolCmd, DWORD TimeoutInterval)
{
	UCHAR CmdDataBuffer[20] = {0};
	PCOMM_CMD_DATA CmdData = (PCOMM_CMD_DATA)CmdDataBuffer;
	PCONTROL_LIGHT_INFO ControlInfo = (PCONTROL_LIGHT_INFO)Command->Reserved;
	
	CmdData->nCmd = ProtocolCmd;
	memcpy( CmdData->data, ControlInfo, sizeof(CONTROL_LIGHT_INFO) );
	
	return PostCmdToLC( ProgramObject, CmdData, sizeof(CmdData->nCmd) + sizeof(CONTROL_LIGHT_INFO) );
}


static KSTATUS SwitchChannel(PROGRAM_OBJECT ProgramObject,  PLC_COMMAND Command, UCHAR ProtocolCmd, DWORD TimeoutInterval)
{
	UCHAR CmdDataBuffer[20] = {0};
	PCOMM_CMD_DATA CmdData = (PCOMM_CMD_DATA)CmdDataBuffer;
	PSWITCH_CHANNEL_INFO ControlInfo = (PSWITCH_CHANNEL_INFO)Command->Reserved;
	
	CmdData->nCmd = ProtocolCmd;
	memcpy( CmdData->data, ControlInfo, sizeof(SWITCH_CHANNEL_INFO) );
	
	return SendCmdToLC( ProgramObject, CmdData, sizeof(CmdData->nCmd) + sizeof(SWITCH_CHANNEL_INFO) );
}


static KSTATUS SwitchMicroscope(PROGRAM_OBJECT ProgramObject,  PLC_COMMAND Command, UCHAR ProtocolCmd, DWORD TimeoutInterval)
{
	UCHAR CmdDataBuffer[20] = {0};
	PCOMM_CMD_DATA CmdData = (PCOMM_CMD_DATA)CmdDataBuffer;
	PSWITCH_MICROSCOPE_INFO ControlInfo = (PSWITCH_MICROSCOPE_INFO)Command->Reserved;
	
	CmdData->nCmd = ProtocolCmd;
	memcpy( CmdData->data, ControlInfo, sizeof(SWITCH_MICROSCOPE_INFO) );
	
	return SendCmdToLC( ProgramObject, CmdData, sizeof(CmdData->nCmd) + sizeof(SWITCH_MICROSCOPE_INFO) );
}


static KSTATUS TestHardware(PROGRAM_OBJECT ProgramObject,  PLC_COMMAND Command, UCHAR ProtocolCmd, DWORD TimeoutInterval)
{
	UCHAR CmdDataBuffer[20] = {0};
	PCOMM_CMD_DATA CmdData = (PCOMM_CMD_DATA)CmdDataBuffer;
	PTEST_HARDWARE_INFO ControlInfo = (PTEST_HARDWARE_INFO)Command->Reserved;
	
	CmdData->nCmd = ProtocolCmd;
	memcpy( CmdData->data, ControlInfo, sizeof(TEST_HARDWARE_INFO) );
	
	return PostCmdToLC( ProgramObject, CmdData, sizeof(CmdData->nCmd) + sizeof(TEST_HARDWARE_INFO) );
}


static KSTATUS ClearTrouble(PROGRAM_OBJECT ProgramObject,  PLC_COMMAND Command, UCHAR ProtocolCmd, DWORD TimeoutInterval)
{
	UCHAR CmdDataBuffer[20] = {0};
	PCOMM_CMD_DATA CmdData = (PCOMM_CMD_DATA)CmdDataBuffer;
	PCLEAR_TROUBLE_INFO ControlInfo = (PCLEAR_TROUBLE_INFO)Command->Reserved;
	
	CmdData->nCmd = ProtocolCmd;
	memcpy( CmdData->data, ControlInfo, sizeof(CLEAR_TROUBLE_INFO) );
	
	return PostCmdToLC( ProgramObject, CmdData, sizeof(CmdData->nCmd) + sizeof(CLEAR_TROUBLE_INFO) );
}

static KSTATUS CorrectModule(PROGRAM_OBJECT PrgObject, PLC_COMMAND Command, UCHAR ProtocolCmd, DWORD TimeoutInterval)
{
	COMM_CMD_DATA CmdData = {0};
	PCORRECT_MODULE_INFO CorrectModuleInfo = (PCORRECT_MODULE_INFO)Command->Reserved;


	CmdData.nCmd = ProtocolCmd;
	KSTATUS ss= SendCmdToLC( PrgObject, &CmdData, COMM_CMD_LENGTH, (char *)CorrectModuleInfo, sizeof(CORRECT_MODULE_INFO), TimeoutInterval );

	DBG_MSG("CorrectModule %d",CorrectModuleInfo->IsSuccess);
	return ss;
}


static KSTATUS TestPaper(PROGRAM_OBJECT PrgObject, PLC_COMMAND Command, UCHAR ProtocolCmd, DWORD TimeoutInterval)
{
	COMM_CMD_DATA CmdData = {0};
	PTEST_PAPER_INFO TestPaperInfo = (PTEST_PAPER_INFO)Command->Reserved;

	CmdData.nCmd = ProtocolCmd;
	return SendCmdToLC( PrgObject, &CmdData, COMM_CMD_LENGTH, (char *)TestPaperInfo, sizeof(TEST_PAPER_INFO), TimeoutInterval );
}

static KSTATUS TestPaperAD(PROGRAM_OBJECT PrgObject, PLC_COMMAND Command, UCHAR ProtocolCmd, DWORD TimeoutInterval)
{
	COMM_CMD_DATA CmdData = {0};
	PTEST_PAPER_AD TestPaperADvalue = (PTEST_PAPER_AD)Command->Reserved;

	CmdData.nCmd = ProtocolCmd;
	return SendCmdToLC( PrgObject, &CmdData, COMM_CMD_LENGTH, (char *)TestPaperADvalue, sizeof(TEST_PAPER_AD), TimeoutInterval );
}

static KSTATUS SpecifyPaperType(PROGRAM_OBJECT PrgObject, PLC_COMMAND Command, UCHAR ProtocolCmd, DWORD TimeoutInterval)
{
	char Buffer[50] = {0};
	char IniFile[MAX_PATH] = {0};
	PCOMM_CMD_DATA CmdData = (PCOMM_CMD_DATA) Buffer;
	PSPECIFY_PAPER_TYPE_INFO SpecifyPaperTypeInfo = (PSPECIFY_PAPER_TYPE_INFO)Command->Reserved;

	CmdData->nCmd = ProtocolCmd;	

	CmdData->data[0] = SpecifyPaperTypeInfo->PaperType;            
	return SendCmdToLC( PrgObject, CmdData, COMM_CMD_LENGTH + sizeof(SpecifyPaperTypeInfo->PaperType), (char *)&(SpecifyPaperTypeInfo->IsSuccess), sizeof(SpecifyPaperTypeInfo->IsSuccess), TimeoutInterval );
}

static KSTATUS FocusZ(PROGRAM_OBJECT ProgramObject,  PLC_COMMAND Command, UCHAR ProtocolCmd, DWORD TimeoutInterval)
{
	UCHAR CmdDataBuffer[20] = {0};
	PCOMM_CMD_DATA CmdData = (PCOMM_CMD_DATA)CmdDataBuffer;
	PMOVE_Z_FOCUS MovezInfo = (PMOVE_Z_FOCUS)Command->Reserved;

	CmdData->nCmd = ProtocolCmd;
	memcpy( CmdData->data, MovezInfo, sizeof(MOVE_Z_FOCUS) );

	if (RETURN_SAMPLE_CMD == MovezInfo->IsReturnTakePicCommand)
	{
		return SendCmdToLC( ProgramObject, CmdData, sizeof(CmdData->nCmd) + sizeof(MOVE_Z_FOCUS), NULL, 0, TimeoutInterval );
	}
	else
	{
		return PostCmdToLC( ProgramObject, CmdData, sizeof(CmdData->nCmd) + sizeof(MOVE_Z_FOCUS) );
	}
}

static KSTATUS AllowTest(PROGRAM_OBJECT ProgramObject,  PLC_COMMAND Command, UCHAR ProtocolCmd, DWORD TimeoutInterval)
{
	UCHAR CmdDataBuffer[20] = {0};
	PCOMM_CMD_DATA CmdData = (PCOMM_CMD_DATA)CmdDataBuffer;
	PCONTROL_ALLOWTEST ControlAllowTest = (PCONTROL_ALLOWTEST)Command->Reserved;

	CmdData->nCmd = ProtocolCmd;
	memcpy( CmdData->data, ControlAllowTest, sizeof(CONTROL_ALLOWTEST) );

	return PostCmdToLC( ProgramObject, CmdData, sizeof(CmdData->nCmd) + sizeof(CONTROL_ALLOWTEST) );
}

static KSTATUS ConsumablesSurplus(PROGRAM_OBJECT ProgramObject, PLC_COMMAND Command, UCHAR ProtocolCmd, DWORD TimeoutInterval)
{
	UCHAR CmdDataBuffer[20] = { 0 };
	PCOMM_CMD_DATA CmdData = (PCOMM_CMD_DATA)CmdDataBuffer;
	PCONSUMABLE_SURPLUS_INFO ConsumableSurplus = (PCONSUMABLE_SURPLUS_INFO)Command->Reserved;

	CmdData->nCmd = ProtocolCmd;
	memcpy(CmdData->data, ConsumableSurplus, sizeof(CONSUMABLE_SURPLUS_INFO));

	return PostCmdToLC(ProgramObject, CmdData, sizeof(CmdData->nCmd) + sizeof(CONSUMABLE_SURPLUS_INFO));
}

extern PROGRAM_OBJECT g_UW2000Object;
extern KSTATUS StartSPort(PROGRAM_OBJECT  PrgObject, PSTART_LC_PAR pStartLC);
extern KSTATUS StopSPort(PROGRAM_OBJECT  PrgObject);

static KSTATUS JustPostCmdToLC(PROGRAM_OBJECT ProgramObject,  PLC_COMMAND Command, UCHAR ProtocolCmd, DWORD TimeoutInterval)
{
	KSTATUS Status = STATUS_SUCCESS;
	COMM_CMD_DATA CmdData = {0};
	
	CmdData.nCmd = ProtocolCmd;
	
	Status = PostCmdToLC( ProgramObject, &CmdData );
	CheckResultCode("PostCmdOnly", "JustPostCmdToLC", Status);
	
end:
	return Status;
}


static UCProtocolCmdInfo g_UCHandleCmdInfoList[] = 
{
	LC_SELF_CHECK,						PROTO_UC_SELF_CHECK,				JustSendCmdToLC,				TIME_INTERVAL_2S,
	LC_ENABLE_AUTO_CHECK,               PROTO_UC_ENABLE_AUTO_CHECK,			EnableAutoCheck,				TIME_INTERVAL_2S,
	LC_DISABLE_AUTO_CHECK,				PROTO_UC_DISABLE_AUTO_CHECK,		JustSendCmdToLC,				TIME_INTERVAL_5S,
	LC_SEND_TASKID,						PROTO_UC_NOTIFY_TASK_ID,			NotifyTaskID,					TIME_INTERVAL_5S,
	LC_LOCATE_10_MICROSCOPE,			PROTO_UC_LOCATE_10_MICROSCOPE,		Locate10Microscope,				TIME_INTERVAL_10S,
	LC_LOCATE_40_MICROSCOPE,			PROTO_UC_LOCATE_40_MICROSCOPE,		Locate40Microscope,				TIME_INTERVAL_10S,
	LC_SAMPLE_FINISH,					PROTO_UC_FINISH_TAKE_PIC,			FinishSample,					TIME_INTERVAL_5S,
	LC_SPECIAL_TEST,					PROTO_UC_SPECIAL_TEST,				StartSpecialTest,				TIME_INTERVAL_5S,
	LC_MOVE_SCAN_PLATFORM,				PROTO_UC_MOVE_SCAN_PLATFORM,		MoveScanPlatform,				TIME_INTERVAL_5S,
	LC_CONTROL_LIGHT,					PROTO_UC_CONTROL_LIGHT,			    ControlLight,					TIME_INTERVAL_5S,
	LC_SWITCH_CHANNEL,					PROTO_UC_SWITCH_CHANNEL,			SwitchChannel,					TIME_INTERVAL_5S,
	LC_SWITCH_MICROSCOPE,				PROTO_UC_SWITCH_MICROSCOPE,			SwitchMicroscope,				TIME_INTERVAL_5S,
	LC_RESET_X,							PROTO_UC_RESET_X,					JustSendCmdToLC,				INVALID_TIME_INTERVAL,
	LC_RESET_Y,							PROTO_UC_RESET_Y,					JustSendCmdToLC,				INVALID_TIME_INTERVAL,
	LC_RESET_Z,							PROTO_UC_RESET_Z,					JustSendCmdToLC,				TIME_INTERVAL_10S,
	LC_TEST_HARDWARE,					PROTO_UC_TEST_HARDWARE,				TestHardware,					TIME_INTERVAL_5S,
	LC_CLEAR_TROUBLE,					PROTO_UC_CLEAR_TROUBLE,				ClearTrouble,					TIME_INTERVAL_5S,
	LC_QUERY_Z_POS,						PROTO_UC_QUERY_Z_POS,				QueryZPos,						TIME_INTERVAL_5S,
	LC_RETURN_XY_40_MICRO_DEVIA,		PROTO_UC_QUERY_XY_40_MICRO_DEVIA,	QueryXy40MicroDevia,			TIME_INTERVAL_5S,
	LC_NORMAL_CLEAR,					PROTO_UC_CLEAR,						ClearLC,						TIME_INTERVAL_240S,
	LC_FORCE_CLEAR,						PROTO_UC_FORCE_CLEAR,				ClearLC,						TIME_INTERVAL_510S,
	LC_QUERY_LC_PARAMETERS,				PROTO_UC_GET_LC_PARAMETERS,			GetLCParameters,				TIME_INTERVAL_5S,
	LC_SET_LC_PARAMETERS,				PROTO_UC_SET_LC_PARAMETERS,			SetLCParameters,				TIME_INTERVAL_5S,
	LC_ENTER_HARDWARE_DEBUG,			PROTO_UC_ENTER_HARDWARE_DEBUG,		JustSendCmdToLC,				TIME_INTERVAL_5S,
	LC_EXIT_HARDWARE_DEBUG,				PROTO_UC_EXIT_HARDWARE_DEBUG,		JustSendCmdToLC,				TIME_INTERVAL_5S,
	LC_RESTART_LC,						PROTO_UC_RESTART_LC,				JustPostCmdToLC,				INVALID_TIME_INTERVAL,
	LC_MOVE_Z,							PROTO_UC_MOVE_Z,					MoveZAxis,						TIME_INTERVAL_10S,
	PROTO_UC_ENABLE_PIPE_IN,			PROTO_UC_ENABLE_PIPE_IN,			JustPostCmdToLC,				TIME_INTERVAL_5S,
	PROTO_UC_DISABLE_PIPE_IN,			PROTO_UC_DISABLE_PIPE_IN,			JustPostCmdToLC,				TIME_INTERVAL_5S,
	
	//UDC����У׼
	LC_UDC_CORRECT_MODULE,				PROTO_UC_CORRECT_MODULE,				CorrectModule,				TIME_INTERVAL_60S,
	//UDC����У׼
	LC_UDC_CORRECT_MODULE_EX,           PROTO_UC_CORRECT_MODULE_EX,             CorrectModule,              TIME_INTERVAL_60S,
	//UDC���
	LC_UDC_TEST_PAPER,					PROTO_UC_TEST_PAPER,					TestPaper,					TIME_INTERVAL_30S,
	//UDC����ֽ������
	LC_UDC_SPECIFY_PAPER_TYPE,			PROTO_UC_SPECIFY_PAPER_TYPE,			SpecifyPaperType,			TIME_INTERVAL_30S,
	//UDC��
	LC_UDC_CONTROL_LIGHT,				PROTO_UC_CONTROL_LED,					ControlLight,				TIME_INTERVAL_30S,
	//�۽�����                         
	LC_FOCUS_Z,                         PROTO_UC_FOCUSMOVE_Z,					FocusZ,						TIME_INTERVAL_30S,
	LC_GET_AD,                          PROTO_UC_GETAD,                         TestPaperAD,                TIME_INTERVAL_25S,
	LC_ALLOW_TEST,                      PROTO_UC_ALLOWTEST,						AllowTest,					TIME_INTERVAL_5S,

	LC_CONSUMABLE_SURPLUS,				PROTO_UC_CONSUMABLES_FLAG,				ConsumablesSurplus,
	TIME_INTERVAL_2S,
};

static bool IsUCDirectHandleCmd(UCHAR UCCmd, DWORD &CmdIndex)
{
	for (CmdIndex = 0; CmdIndex < GetItemCount(g_UCHandleCmdInfoList); ++CmdIndex)
	{
		if (UCCmd == g_UCHandleCmdInfoList[CmdIndex].UCCmd)
		{
			return true;
		}
	}

	return false;
}

KSTATUS HandleUCCmd(PROGRAM_OBJECT  PrgObject, PRP prp)
{
	DWORD CmdIndex = 0;
	ULONG nInSize = 0;
	KSTATUS Status = STATUS_SUCCESS;
	PLC_COMMAND lp_cmd;

	Status = FMMC_GetPRPParmeters(prp, (PVOID *)&lp_cmd, &nInSize, NULL, NULL);
	CheckResultCode("DispatchCmd", "FMMC_GetPRPParmeters", Status);
	
	DbgPrint("enter HandleUCCmd %#x\n", lp_cmd->lc_header.nLCCmd);

	if( nInSize != sizeof(LC_COMMAND) || lp_cmd->lc_header.flag != LC_FLAG )
	{
		DbgPrint( "if( nInSize != sizeof(LC_COMMAND) || lp_cmd->lc_header.flag != LC_FLAG )" );
		Status = STATUS_INVALID_PARAMETERS;
		goto end;
	}
	
	if ( IsUCDirectHandleCmd(lp_cmd->lc_header.nLCCmd, CmdIndex) )
	{
		Status = g_UCHandleCmdInfoList[CmdIndex].UCCmdFunc(PrgObject, lp_cmd, g_UCHandleCmdInfoList[CmdIndex].UCProtocolCmd,  g_UCHandleCmdInfoList[CmdIndex].TimeoutInterval);
	}
	else
	{
		DbgPrint("UC Cmd %#x is not handled!!!!!", lp_cmd->lc_header.nLCCmd);
		Status = STATUS_UNKNOW_ERROR;
	}
	
end:
	return Status;
}